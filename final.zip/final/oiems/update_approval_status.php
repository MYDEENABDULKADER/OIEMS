<?php
include('db.php');
require_once("php-mailer/PHPMailer.php");
require_once("php-mailer/SMTP.php");
require_once("php-mailer/Exception.php");

use PHPMailer\PHPMailer\PHPMailer;

// Email configuration
$smtpHost = 'smtp.gmail.com';
$smtpUsername = 'abc982867@gmail.com';
$smtpPassword = 'ipgm xixc idev xzby';
$smtpSecure = 'tls';
$smtpPort = 587;
$senderEmail = 'abc982867@gmail.com';
$senderName = 'Event Management System';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && isset($_POST['guestid']) && isset($_POST['deptmail'])) {
        $action = $_POST['action'];
        $guestid = $_POST['guestid'];
        $deptmail = $_POST['deptmail'];

        if ($action == 'approve') {
            updateApprovalStatus($guestid,$deptmail, 'APPROVED');
        } elseif ($action == 'reject') {
            updateApprovalStatus($guestid,$deptmail, 'NOT_APPROVED');
        }
    }
}


function updateApprovalStatus($guestid,$mail, $status) {
    global $conn;

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sanitize user input
    $guestid = mysqli_real_escape_string($conn, $guestid);
    $status = mysqli_real_escape_string($conn, $status);

    $sql = "UPDATE guest_table SET approval_status = '$status' WHERE guestid = '$guestid'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "Update successful";
        sendApprovalEmail($mail, "You are Approved");
    } else {
        // Log the error and provide a user-friendly message
        error_log("Update failed: " . mysqli_error($conn));
        sendApprovalEmail($mail, "You are Rejected");

        echo "Update failed. Please try again later.";
    }

    mysqli_close($conn);
}

function sendApprovalEmail( $recipient, $approvalStatus) {
    global $smtpHost, $smtpUsername, $smtpPassword, $smtpSecure, $smtpPort, $senderEmail, $senderName;

    // Generate a random password


    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = $smtpHost;
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtpUsername;
        $mail->Password   = $smtpPassword;
        $mail->SMTPSecure = $smtpSecure;
        $mail->Port       = $smtpPort;

        // Sender and recipient settings
        $mail->setFrom($senderEmail, $senderName);
        $mail->addReplyTo($recipient, "fdsa");
        $mail->addAddress($recipient);

        $mail->isHTML(false);

        // Email content
        $mail->Subject = 'Approval Status';
        $mail->Body    = 'Thanks for Registering ' . $approvalStatus;

        // Send the email
        try {
            //$mail->SMTPDebug = 2; // Set to 2 for maximum debugging information
            $mail->send();
            redirectToIndex();
        } catch (Exception $e) {
            error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
            echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
    }
}

function redirectToIndex()
{
    header("Location: ./guestmanagement.php");
    exit;
}
?>
