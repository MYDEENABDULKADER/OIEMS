<?php
include('db.php');
include('random_number.php');

if(isset($_POST['submit'])) {
    $collegename = $_POST['CollegeName'];
    $deptname = $_POST['Departmentname'];
    $deptincharge = $_POST['Departmentincharge'];
    $deptmail = $_POST['Departmentmail'];
    $inch_num = $_POST['phone'];
    $eventname = $_POST['eventname'];
    $meals = $_POST['MealPreferences'];
    $guestid = generateUniquePrimaryKey();

    $sql = "INSERT INTO guest_table (guestid, collegename, deptname, deptincharge, deptmail, inch_num, eventname, meals, approval_status)
            VALUES ('$guestid', '$collegename', '$deptname', '$deptincharge', '$deptmail', '$inch_num', '$eventname', '$meals', 'NOT_APPROVED')";

    $result = mysqli_query($conn, $sql);

    if($result) {
        $lastguestID = mysqli_insert_id($conn);

        $numberOfCompetitions = $_POST['numberOfCompetitions'];
        for ($i = 1; $i <= $numberOfCompetitions; $i++) {
            $partname = $_POST["participantname${i}"];
            $yearofstudy = $_POST["yearofstudy${i}"];
        
            $competitionschk = "chk" . $i;
            $compnames = '';
            // Retrieve selected competition names for the current participant
            $compArray = $_POST[$competitionschk]; // Assuming the checkboxes are named as competitions1, competitions2, etc.
            foreach($compArray as $comps){
                $qry = "select * from comp_table where comp_id=" . $comps;
                // echo $qry;
                $result = mysqli_query($conn, $qry);
                $row = mysqli_fetch_assoc($result);
                // print_r($result);
                
                $compnames = $compnames . ', ' . $row['comp_name'];
            }
            
            // $compNames = implode(',', $compArray); // Combine selected competition names
            // echo $compNames;
            
            // Insert participant details into participants table along with combined competition names
            $insertParticipantQuery = "INSERT INTO participants (partname, yearofstudy, comp, guestid) 
                                        VALUES ('$partname', '$yearofstudy', '$compnames', '$guestid')";
            $insertParticipantResult = mysqli_query($conn, $insertParticipantQuery);
        
            if(!$insertParticipantResult) {
                // Handle participant insertion failure
                die(mysqli_error($conn));
            }
        }
        

        header('location:home.php');
    } else {
        die(mysqli_error($conn));
    }
}
?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            justify-content: center;
            align-items: center;
        }

        form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 70%;
            width: 100%;
            margin: 20px auto;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin: 15px 0 5px;
            color: #555;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .custom-alert {
            display: none;
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #4caf50;
            color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            cursor:pointer;
        }
        #resetBtn {
            background-color: red; /* Change button background color to red */
            color: white; /* Change text color to white */
            border: none; /* Remove button border */
            padding: 10px 20px; /* Add padding */
            cursor: pointer; /* Change cursor to pointer on hover */
            float: right; /* Float the button to the right */
            margin-left: 10px; /* Add some margin between buttons */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            color: #212529;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tbody+tbody {
            border-top: 2px solid #dee2e6;
        }
    </style>
</head>
<title>Guest Registration Form</title>
<body>
   
    <form action="" method="post" id="registrationForm" onsubmit="return validateForm()">
        <h1>Registration Form</h1>
        <label for="CollegeName">College Name:</label>
        <input type="text" id="CollegeName" name="CollegeName" required>

        <label for="Departmentname">Department Name</label>
        <input type="text" id="Departmentname" name="Departmentname" required>

        <label for="Departmentincharge">Department Incharge</label>
        <input type="text" id="Departmentincharge" name="Departmentincharge" required>

        <label for="Departmentmail">Department Mail Address</label>
        <input type="email" id="Departmentmail" name="Departmentmail" required>

        <label for="phone">Incharge Contact Number:</label>
        <input type="tel" id="phone" name="phone" required>

        <label for="eventname">Event Name:</label>
        <select name="eventname" id="eventname" required onchange="getComp(); ">
        <option>--Choose Event--</option>
        <?php
            // Establish connection to your database
            $connection = mysqli_connect("localhost", "root", "", "oiems");

            // Check connection
            if (mysqli_connect_errno()) {
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
                exit();
            }

            // Fetch event names from the eventtable
            // Fetch event names and IDs from the eventtable
            $query = "SELECT eventid, eventname FROM eventtable";
            $result = mysqli_query($connection, $query);

            // Check if query was successful
            if (!$result) {
                echo "Error: " . mysqli_error($connection);
                exit();
            }

            // Loop through the results and populate the dropdown options
            while ($row = mysqli_fetch_assoc($result)) {

                // echo "<option value=''>Select the event Name</option>";
                echo "<option value='" . $row['eventid'] . "|" . $row['eventname'] . "'>" . $row['eventname'] . "</option>";
            }

            // Close database connection
            mysqli_close($connection);
?>
        </select>
        <div id="allcomp"></div>

        <label for="mealPreferences">Meal Preferences:</label>
        <select id="mealPreferences" name="MealPreferences" required>
            <option value="yes">Yes</option>
            <option value="no">No</option>
        </select>

        <label for="numberOfCompetitions">Number of Participants:</label>
        <input type="number"  id="numberOfCompetitions" name="numberOfCompetitions" onblur="onBlurGenerateCompetitionInputs()" >

        <table>
            <thead>
                <tr>
                    <th>Participant  Name</th>
                    <th>Year of Study</th>
                    <th>Competitions</th>
                    
                </tr>
            </thead>
            <tbody>
                <!-- Competition rows will be dynamically generated here based on user input -->
            </tbody>
        </table>
        <br><br>
        <div class="div">
            <button type="submit" name="submit" id="submitBtn">Register</button>
            <button type="reset" id="resetBtn">Reset</button>
        </div>
    </form>
  
    <div class="custom-alert" id="customAlert">
        Thank you for registering! You will be notified by the admin.
        <span onclick="closeCustomAlert()">&times;</span>
    </div>


</body>
</html>
<script>
     
   
    function validateForm() {
        var collegeName = document.getElementById('CollegeName').value;
        var departmentName = document.getElementById('Departmentname').value;
        var departmentIncharge = document.getElementById('Departmentincharge').value;
        var departmentMail = document.getElementById('Departmentmail').value;
        var inchargeContactNumber = document.getElementById('phone').value;
        var eventName = document.getElementById('eventname').value;
        var mealPreferences = document.getElementById('mealPreferences').value;
        
        // Simple validation for required fields
        if (!collegeName || !departmentName || !departmentIncharge || !departmentMail || !inchargeContactNumber || !eventName || !mealPreferences) {
            alert('Please fill out all required fields.');
            return false;
        }

        // Validate phone number length
        if (inchargeContactNumber.length !== 10) {
            alert('Phone number must be 10 digits.');
            return false;
        }
       
        //show the alert message
        alert('Thanks for Registering! You will be notified by the admin');
        
        // Allow the form to submit
        return true;
      
    }
    function onBlurGenerateCompetitionInputs() {
        const numberOfCompetitions = parseInt(document.getElementById('numberOfCompetitions').value, 10);
        const competitionTableBody = document.querySelector('table tbody');
        competitionTableBody.innerHTML = '';

        for (let i = 1; i <= numberOfCompetitions; i++) {
            const competitionRow = document.createElement('tr');
                var temp = '';
              temp = `
                <td>
                    <input type="text" name="participantname${i}" placeholder="Enter Participant Name" required>
                </td>
                <td>
                    <select name="yearofstudy${i}">
                        <option value="">Select year</option>
                        <option value="I">First Year</option>
                        <option value="II">Second Year</option>
                        <option value="III">Third Year</option>
                        <option value="IV">Fourth Year</option>
                    </select>
                </td>
                <td>
            `;

            var total = document.getElementById('txtTotalEvents').value;

            var ename;
            var eid;
            var eventname;
            var eventid;
            for(var j = 1; j <= total; j++){
                ename = "txtename" + j;
                eid = "txteid" + j;
                
                eventname = document.getElementById(ename).value;
                eventid = document.getElementById(eid).value;

                temp += '<input type=checkbox  name=chk'+ i + '[] id=chk'+ i +  '[]  value=' + eventid + ' />' + eventname;
                // alert(eventid + " " + eventname);
            }
            temp += '</td>';
            
            competitionRow.innerHTML = temp;
            competitionTableBody.appendChild(competitionRow);
            
            getEventIdAndFetchCompetitions();
        }
    }

function getEventIdAndFetchCompetitions() {
    var selectedValue = document.getElementById('eventname').value;    
    var eventId = selectedValue.split("|")[0]; // Extracting eventid from the selected value
        getCompetitions(eventId); // Call function to fetch competitions based on eventid
    }

function getCompetitions(eventId) {
    // const numberOfCompetitions = parseInt(document.getElementById('numberOfCompetitions').value, 10);
    // var xhttp = new XMLHttpRequest();
    // xhttp.onreadystatechange = function () {
    //     if (this.readyState == 4 && this.status == 200) {
            
    //         var checkboxes = this.responseText;

            
    //         var rows = document.querySelectorAll('table tbody tr');

            
    //         rows.forEach(function(row) {
    //             row.querySelector('td:last-child').innerHTML = checkboxes;
    //         });
    //     }
    // };
    // xhttp.open("GET", "get_competitions.php?eventid=" + eventId + "&total=" + numberOfCompetitions, true);
    // xhttp.send();
}

function getComp(){
    var selectedValue = document.getElementById('eventname').value;    
    var eventId = selectedValue.split("|")[0]; // Extracting eventid from the selected value
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById('allcomp').innerHTML =  this.responseText;
            onBlurGenerateCompetitionInputs();
        }
    };
    xhttp.open("GET", "getcomp.php?eventid=" + eventId, true);
    xhttp.send();
}


        
</script>
