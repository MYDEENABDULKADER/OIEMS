<?php
require_once('db.php');

function validateLogin($username, $password, $conn)
{
    $stmt = $conn->prepare("SELECT * FROM user WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($password == $user['password']) {
            if ($user["role"] == "hod") {
                header("location:hod.php");
            } elseif ($user["role"] == "staff") {
                header("location:staff.php");
            } elseif ($user["role"] == "admin") {
                header("location:admin.php");
            } elseif ($user["role"] == "viceprincipal") {
                header("location:vp.php");
            }
            
            session_start();
            $_SESSION['loggedIn'] = '1';
            $_SESSION['fullName'] = $user['firstName']; 
            return true;

        }
    }

    return false;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // if (validateLogin($username, $password, $conn)) {
    //     echo "Login successful!"; `// This message will not be displayed after a successful redirection
    // } else {
    //     echo "Invalid username or password";
    // }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (validateLogin($username, $password, $conn)) {
        
        echo "<script>alert('Successful Login');</script>";
        header('location:hod.php');

    } else {
        echo "<script>alert('Invalid username or password');</script>";
    }
}
$conn->close();

?> 
