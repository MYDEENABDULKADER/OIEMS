<?php
include('db.php');
if(isset($_GET['deleteid'])){
    $comp_id=$_GET['deleteid'];
    $sql="delete from `comp_table` where comp_id='$comp_id'";
    $result=mysqli_query($conn,$sql);
    if($result){
        header('location:event_management.php');
    }
    else{
        die(mysqli_error($conn));
    }
}
?>