<?php
// delete_notice.php

include("../db.php");

if(isset($_GET['id'])) {
    $notice_id = $_GET['id'];

    // Delete notice from the database based on the notice_id
    $sql = "DELETE FROM Notices WHERE notice_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $notice_id);
    if($stmt->execute()) {
        header('Location: notice.php');
        exit();
    } else {
        echo "Error deleting notice.";
        exit();
    }
} else {
    echo "Notice ID not provided.";
    exit();
}
?>
