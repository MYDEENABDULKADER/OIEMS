<?php
// Assuming you have already established a database connection
// Include any necessary configuration files or functions

// Initialize variables to store form input
$title = $content = $link = $expiration_date = '';
$errors = array();

// Check if notice ID is provided
if(isset($_GET['id']) && !empty($_GET['id'])) {
    $notice_id = $_GET['id'];
    include("../db.php");
    // Fetch notice data from database
    $sql = "SELECT * FROM Notices WHERE notice_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $notice_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Assign fetched data to variables
        $title = $row['title'];
        $content = $row['content'];
        $link = $row['link'];
        $expiration_date = $row['expiration_date'];
    } else {
        // Notice not found, redirect or show error message
        header("Location: notice_not_found.php");
        exit();
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $title = $_POST['title'];
    $content = $_POST['content'];
    $expiration_date = $_POST['expiration_date'];

    // Handle file upload
    if ($_FILES['file']['size'] > 0) {
        $uploadDir = 'uploads/'; // Directory where uploaded files will be stored
        $uploadFile = $uploadDir . basename($_FILES['file']['name']);

        if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
            $link = $uploadFile;
        } else {
            $errors['file'] = "File upload failed";
        }
    }

    // Validate form inputs (you can add more validation as needed)
    if (empty($title)) {
        $errors['title'] = "Title is required";
    }
    if (empty($content)) {
        $errors['content'] = "Content is required";
    }

    // If no errors, update notice in database
    if (empty($errors)) {
        include("../db.php");
        // Prepare SQL statement
        $sql = "UPDATE Notices SET title = ?, content = ?, link = ?, expiration_date = ? WHERE notice_id = ?";
        // Prepare and bind parameters
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $title, $content, $link, $expiration_date, $notice_id);
        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to a confirmation page or display a success message
            header("Location: notice.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Notice</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .error {
            color: red;
        }

        .form-container {
            max-width: 400px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <div class="form-container">
                    <div class="card">
                        <div class="card-header">
                            Update Notice
                        </div>
                        <div class="card-body">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="title">Title:</label>
                                    <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($title); ?>">
                                    <span class="error"><?php echo $errors['title'] ?? ''; ?></span>
                                </div>
                                <div class="form-group">
                                    <label for="content">Content:</label>
                                    <textarea class="form-control" id="content" name="content"><?php echo htmlspecialchars($content); ?></textarea>
                                    <span class="error"><?php echo $errors['content'] ?? ''; ?></span>
                                </div>
                                <div class="form-group">
                                    <label for="file">File:</label>
                                    <input type="file" class="form-control-file" id="file" name="file">
                                    <span class="error"><?php echo $errors['file'] ?? ''; ?></span>
                                </div>
                                <div class="form-group">
                                    <label for="expiration_date">Expiration Date:</label>
                                    <input type="date" class="form-control" id="expiration_date" name="expiration_date" value="<?php echo htmlspecialchars($expiration_date); ?>">
                                </div>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
