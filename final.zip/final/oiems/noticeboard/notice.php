<?php 

session_start();

?>


<?php
if (!isset($_SESSION['loggedIn'])) {
    header('Location:../home.php');
    exit();
}
?>

<?php
$title = $content = $link =  '';
$errors = array();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $uploadDir = 'uploads/';
    $uploadFile = $uploadDir . basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
        $link = $uploadFile;
    } else {
        $errors['file'] = "File upload failed";
    }

    if (empty($title)) {
        $errors['title'] = "Title is required";
    }
    if (empty($content)) {
        $errors['content'] = "Content is required";
    }

    // If no errors, insert notice into database
    if (empty($errors)) {
        // Prepare SQL statement
        include("../db.php");

        // Prepare SQL statement
        $sql = "INSERT INTO Notices (title, content, link) 
            VALUES (?, ?, ?)";

        // Prepare and bind parameters
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $title, $content, $link);

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to a confirmation page or display a success message
            header("Location: notice.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: white;

        }

        h1 {
            color: #333;
            text-align: center;
        }

        a {
            text-decoration: underline;
        }

        button {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: inline-block;
            transition: background-color 0.3s ease;
            margin: 5%;
            width: 50%;
            height: 10%;
            align-items: center;
        }

        button:hover {

            background-color: #2980b9;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        thead {
            color: black;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tbody tr:hover {
            background-color: #f5f5f5;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
        }

        /* nav a:hover {
            background-color: #555;
        } */

        p {
            font-size: larger;
            color: black;
            text-align: center;
            margin-top: 25px;
            cursor: pointer;
            text-decoration: none;

        }

        p:hover {
            cursor: pointer;
            color: maroon;
        }
    </style>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>

<body>
    <h1>Notice Board</h1>
    <nav>
        <a href="../admin.php">Admin</a>
        <a href="../staff_management.php">Staff Management</a>
        <a href="../event_management.php">Event Management</a>
        <a href="../reportPdf.php">Reports</a>
        <a href="../guestmanagement.php">Guest Management</a>
        <a href="notice.php">Notice Board</a>
        <a href="../feedbackmanagement.php">Feedback</a>
        <a href="../logout.php">Logout</a>
        <!-- <a href="#">Button</a> -->
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <div class="form-container">
                    <div class="card">
                        <div class="card-header">
                            Add Notice
                        </div>
                        <div class="card-body">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="title">Title:</label>
                                    <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($title); ?>">
                                    <span class="error">
                                        <?php echo $errors['title'] ?? ''; ?>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label for="content">Content:</label>
                                    <textarea class="form-control" id="content" name="content"><?php echo htmlspecialchars($content); ?></textarea>
                                    <span class="error">
                                        <?php echo $errors['content'] ?? ''; ?>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label for="file">File:</label>
                                    <input type="file" class="form-control-file" id="file" name="file">
                                    <span class="error">
                                        <?php echo $errors['file'] ?? ''; ?>
                                    </span>
                                </div>
                               
                                <center> <button type="submit" class="btn btn-primary">Submit</button></center>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h3>Notices</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Content</th>
                            <th>Link</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include('../db.php');
                        $notices = array();
                        $sql = "SELECT * FROM Notices";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $notices[] = $row;
                            }
                        }
                        foreach ($notices as $notice) : ?>
                            <tr>
                                <td>
                                    <?php echo htmlspecialchars($notice['title']); ?>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($notice['content']); ?>
                                </td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($notice['link']); ?>" target="_blank">
                                        <?php echo htmlspecialchars(basename($notice['link'])); ?>
                                    </a>
                                </td>
                                

                                <td>
                                    <!-- <a href="edit_notice.php?id=<?php echo $notice['notice_id']; ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a> -->
                                    <a href="delete_notice.php?id=<?php echo $notice['notice_id']; ?>" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>