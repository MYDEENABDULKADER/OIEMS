<?php
// Check if the URL parameter is set
if (isset($_GET['url'])) {
    // Decode the URL parameter
    $fileUrl = urldecode($_GET['url']);

    // Check if the file exists
    if (file_exists($fileUrl)) {
        // Set headers for file download
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($fileUrl));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($fileUrl));
        readfile($fileUrl); // Output the file
        exit;
    } else {
        echo 'File not found.';
    }
} else {
    echo 'Invalid request.';
}
