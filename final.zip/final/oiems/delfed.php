<?php
include('db.php');
if(isset($_GET['deleteid'])){
    $fid=$_GET['deleteid'];

    $sql="delete from `feedback` where f_id=$fid";
    $result=mysqli_query($conn,$sql);
    if($result){
        header('location:feedbackmanagement.php');
    }
    else{
        die(mysqli_error($conn));
    }
}
?>