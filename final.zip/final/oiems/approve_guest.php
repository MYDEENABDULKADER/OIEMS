<?php
session_start();
if (!isset($_SESSION['loggedIn'])) {
  header('Location:home.php');
  exit();
}
?>

<?php
// approve_guest.php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $guestId = $_POST['guestId'];

    // Update the approval status in the database (modify as needed)
    $updateSql = "UPDATE `guest_table` SET `approval_status` = 1 WHERE `guestid` = $guestId";
    $updateResult = mysqli_query($conn, $updateSql);

    if ($updateResult) {
        echo json_encode(['status' => 'success']);
    } else {
        $error_message = mysqli_error($conn);
        error_log("Error updating database: $error_message");
        echo json_encode(['status' => 'error', 'message' => $error_message]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>
