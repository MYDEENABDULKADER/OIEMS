<?php
session_start();
if (!isset($_SESSION['loggedIn'])) {
  header('Location:home.php');
  exit();
}
?>

<?php
require_once('db.php');

if(isset($_POST['submit'])){

    $firstname=$_POST['fname'];
    $lastname=$_POST['lname'];
    $username=$_POST['uname'];
    $password=$_POST['pwd'];
    $age=$_POST['age'];
    $email=$_POST['email']; // added email field
    $gender=$_POST['gender'];
    $role=$_POST['role'];

    $sql="INSERT INTO `user` (firstname, lastname, username, password, age, email, gender, role)
    VALUES ('$firstname', '$lastname', '$username', '$password', '$age', '$email', '$gender', '$role')";
    
    $result=mysqli_query($conn,$sql);
   
    if($result){
        // echo "Data inserted successfully";
        header('location:staff_management.php');
    }
    else{
        die(mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        form {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            position: relative;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        /* .close-button {
            background-color: #f44336;
        } */

    
        .submit-button {
            position: relative;
            bottom: 0;
            left: 50%;
        
        }
    </style>
</head>
<body>

<form action="" method="post">
    <h2>Add User</h2>
    <label for="fname">FirstName:</label>
    <input type="text" name="fname" id="fname" placeholder="Enter Firstname" required>

    <label for="lname">LastName:</label>
    <input type="text" name="lname" id="lname" placeholder="Enter Lastname" required>

    <label for="uname">UserName:</label>
    <input type="text" name="uname" id="uname" placeholder="Enter Username" required>

    <label for="pwd">Password:</label>
    <input type="password" name="pwd" id="pwd" placeholder="Enter password" required>

    <label for="age">Age:</label>
    <input type="number" name="age" id="age" placeholder="Enter Age" required>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" placeholder="Enter email" required>

    <label for="gender">Gender:</label>
    <select id="gender" name="gender">
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </select>

    
    <label for="role">Role:</label>
    <select name="role" id="role">
        <option value="HOD">HOD</option>
        <option value="Event Organiser">Event Organiser</option>
        <option value="Competition Incharge">Competition Incharge</option>
        <option value="Staff">Staff</option>
    </select>

    <button type="submit" name="submit">Submit</button>
</form>



</body>
</html>
