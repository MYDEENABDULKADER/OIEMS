<?php
session_start();
if (!isset($_SESSION['loggedIn'])) {
  header('Location:home.php');
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EventOrganiser</title>
    <style>
            body {
                        font-family: Arial, sans-serif;
                        margin: 20px;
                        background-color: white;
                    
                    }

        h1 {
            color: #333;
            text-align: center;
        }

        a {
            text-decoration: underline;
        }

         button {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: inline-block;
            transition: background-color 0.3s ease;
            margin: 5%;
            width: 10%;
            height: 10%;
        }

          button:hover {

            background-color: #2980b9;
        }

        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        thead {
            color: black;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tbody tr:hover {
            background-color: #f5f5f5;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }
       

        #competitionModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        #competitionModalContent {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        #competitionModalContent table {
            width: 100%;
            border-collapse: collapse;
        }

        #competitionModalContent th,
        #competitionModalContent td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        #competitionModalContent tbody tr:hover {
            background-color: #f5f5f5;
        }  
       
        p {
            font-size:larger;
            color: black;
            text-align: center;
            margin-top: 25px;
            cursor: pointer;
            text-decoration: none;
        
        }

    p:hover {
      cursor: pointer;
      color:maroon;
    }
    
      </style>
</head>

<body>

    <h1>Event Management</h1>
    <nav>
        <a href="admin.php">Admin</a>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Management</a>
        <a href="reportPdf.php">Reports</a>
        <a href="guestmanagement.php">Guest Management</a> 
        <a href="./noticeboard/notice.php">Notice Board</a>
        <a href="feedbackmanagement.php">Feedback</a>
        <a href="logout.php">Logout</a>
        <!-- <a href="#">Button</a> -->
    </nav>
    <a href="addevent.php" >
        <button>Add Event & Competitions</button>
    </a>
    <p> To see the competition details of a event click the event row</p>

    <table id="myTable" border="2px">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>Event Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Location</th>
                <th>Event type</th>
                <th>Event Organiser</th>
                <th>Event Status</th>
                <th colspan="2" style="text-align: center;">Operation</th>
            </tr>
        </thead>
        <tbody id="userTableBody">
            <?php
            include('db.php');
            $sql = "select * from `eventtable`";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                $serialNumber = 1; 

                while ($row = mysqli_fetch_assoc($result)) {
                    $eventid = $row['eventid'];
                    $eventname = $row['eventname'];
                    $startdate = $row['sdate'];
                    $enddate = $row['edate'];
                    $location = $row['location'];
                    $eventtype = $row['etype'];
                    $eventorg = $row['eorganiser'];
                    $eventstatus = $row['estatus'];

                    echo '<tr onclick="openModal(event, \'' . $eventid . '\')">
                                <!-- ... Your existing table row content ... -->
                                <th scope="row">' . $serialNumber++ . '</th>
                                <td>' . $eventname . '</td>
                                <td>' . $startdate . '</td>
                                <td>' . $enddate . '</td>
                                <td>' . $location . '</td>
                                <td>' . $eventtype . '</td>
                                <td>' . $eventorg . '</td>
                                <td>' . $eventstatus . '</td>
                                <td>
                                        <a href="upevent.php?updateid=' . $eventid . '" class="no-modal"  >
                                       Update

                                        </a>
                                </td>
                                <td>
                                    <a href="delevent.php?deleteid=' . $eventid . '" class="no-modal" >
                                    Delete
                                    </a>
                                    </td>

                            </tr>';
                }
            }
            ?>
        </tbody>
    </table>

    <div id="competitionModal">
        <div id="competitionModalContent">
            <span onclick="closeModal()" style="cursor: pointer; position: absolute; top: 10px; right: 10px; font-size: 20px;">&times;</span>
            <table>
                <thead>
                    <tr>
                        <th>Competition ID</th>
                        <th>Competition Name</th>
                        <th>Competition Date</th>
                        <th>Location</th>
                        <th>Competition type</th>
                        <th>Competition incharge</th>
                        <th>Competition fee</th>
                        <th>Operation</th>
                    </tr>
                </thead>
                <tbody id="competitionTableBody">
                    
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>
<script>
    
    function openModal(event, eventId) {
        // Check if the clicked element is an anchor tag (a)
        if (event.target.tagName.toLowerCase() === 'a') {
            // Check if the clicked anchor tag has a specific class (you can adjust the class name accordingly)
            if (event.target.classList.contains('no-modal')) {
                // Do not open the modal for certain links
                return;
            }
        }
        event.preventDefault();

        // Display the modal
        document.getElementById('competitionModal').style.display = 'block';

        // Update the competition details in the modal
        updateCompetitionDetails(eventId);

    }
    function updateCompetitionDetails(eventId) {
        // Fetch competition details based on eventId and update the modal content
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                // Update the competition table body with the fetched details
                document.getElementById('competitionTableBody').innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", 'getcompetitiondetails.php?eventid=' + eventId, true);
        xhttp.send();
    }

    function closeModal() {
        document.getElementById('competitionModal').style.display = 'none';
    }


</script>
