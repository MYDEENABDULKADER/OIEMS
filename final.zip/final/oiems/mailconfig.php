<?php

require_once("php-mailer/PHPMailer.php");
require_once("php-mailer/SMTP.php");
require_once("php-mailer/Exception.php");

use PHPMailer\PHPMailer\PHPMailer;

function redirectToIndex()
{
  header("Location: ./guestmanagement.php");
  exit;
}

function sendMail($name, $email, $message, $subject, $date)
{


  $mail = new PHPMailer();
  $mail->isSMTP();
  $mail->Host = "smtp.gmail.com";
  $mail->SMTPAuth = true;
  $mail->Username = "abc982867@gmail.com";
  $mail->Password = "tpfa bkbw ybog qsfv";
  $mail->Port = 587;

  $mail->setFrom("abc982867@gmail.com", "Event Management System");
  $mail->addReplyTo($email, "Event Management System");
  $mail->addAddress($email);



  $mail->isHTML(false);
  $mail->Subject = $subject;
  $mail->Body = $message;

  if ($mail->send()) {
    $_SESSION["mail_success"] = true;
  } else {
    $_SESSION["mail_error"] = true;
  }

  redirectToIndex();
}

function start()
{
  if (
    isset($_POST["email"]) && !empty(trim($_POST["email"]))
    && isset($_POST["message"]) && !empty(trim($_POST["message"]))
  ) {

    $name = !empty($_POST["name"]) ? $_POST["name"] : "Not informed";
    $email = trim($_POST["email"]);
    $message = trim(str_replace("\n", '<br />', $_POST["message"]));
    $subject = "Contact";
    $date = date("d/m/Y H:i");

    sendMail($name, $email, $message, $subject, $date);
  } else {
    $_SESSION["mail_error"] = true;
    redirectToIndex();
  }
}

start();
