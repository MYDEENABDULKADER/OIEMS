<?php
function generateUniquePrimaryKey($length = 10) {
    // Use uniqid() to generate a unique identifier based on the current timestamp
    $uniqueId = uniqid();

    // Take the first $length characters to get the random string
    $randomString = substr($uniqueId, 0, $length);

    return $randomString;
}

// Example usage:
$randomPrimaryKey = generateUniquePrimaryKey(8); // Change 8 to the desired length
// echo $randomPrimaryKey;
?>
