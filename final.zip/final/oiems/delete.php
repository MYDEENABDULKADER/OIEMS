<?php
include('db.php');
if(isset($_GET['deleteid'])){
    $userid=$_GET['deleteid'];

    $sql="delete from `user` where userid=$userid";
    $result=mysqli_query($conn,$sql);
    if($result){
        header('location:staff_management.php');
    }
    else{
        die(mysqli_error($conn));
    }
}
?>