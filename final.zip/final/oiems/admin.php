<?php
session_start();
// Idha paathuko bro, Idhu dhan check either log in pannnitiya nu paathutu , will let you in
if (!isset($_SESSION['loggedIn'])) {
  header('Location: home.php');
  exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management Page</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: white;
;        }

        h1 {
            color: #333;
            text-align: center;
        }

        a {
            text-decoration: none;
            }

.add-btn button {
    background-color: #3498db;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: inline-block;
    transition: background-color 0.3s ease;
    margin:5%;
    width: 10%;
    height: 10%;
    
}

.add-btn button:hover {
    background-color: #2980b9;


}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

thead {
    color: black;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

tbody tr:hover {
    background-color: #f5f5f5;
}
nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }
        .update-btn button {
    background-color: #007bff; /* Blue background color */
    color: #fff;              /* Text color */
    padding: 12px 20px;        /* Padding around text */
    border: none;             /* No border */
    border-radius: 5px;        /* Rounded corners */
    cursor: pointer;          /* Cursor on hover */
    font-size: 16px;          /* Font size */
}

.update-btn button:hover {
    background-color: #0056b3; /* Darker blue on hover */
}

/* Styles for the Reject button */
.delete-btn button {
    background-color: #dc3545; /* Red background color */
    color: #fff;              /* Text color */
    padding: 12px 20px;        /* Padding around text */
    border: none;             /* No border */
    border-radius: 5px;        /* Rounded corners */
    cursor: pointer;          /* Cursor on hover */
    font-size: 16px;          /* Font size */
}

.delete-btn button:hover {
    background-color: #c82333; /* Darker red on hover */
}
</style>

</head>
<body>

<h1>Admin</h1>
<nav>
        <a href="admin.php">Admin</a>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Organiser</a>
        <a href="guestmanagement.php">Guest Management</a> 
        <a href="reportPdf.php">Reports</a>
        <a href="./noticeboard/notice.php">Notice Board</a>
        <a href="feedbackmanagement.php">Feedback</a>
        <a href="logout.php">Logout</a>

    </nav>

    <body>
    
<table border="2px">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>FirstName</th>
                <th>Lastname</th>
                <th>Username</th>
                <th>Password</th>
                <th>Age</th>
                <th>Email</th>
                <th>gender</th>
                <th>role</th>
                <th colspan="2" style="text-align: center;">Operation</th>
            </tr>
        </thead>
        <tbody id="userTableBody" >
            
        </tbody>
        </body>
        </html>

<?php
include('db.php');
$sql = "select * from `user` where role='HOD' ";
$result = mysqli_query($conn,$sql);
if ($result) {
    $serialNumber = 1; // Initialize serial number

    while ($row = mysqli_fetch_assoc($result)) {
        $userid = $row['userid'];
        $firstname = $row['firstname'];
        $lastname = $row['lastname'];
        $username = $row['username'];
        $password = $row['password'];
        $age = $row['age'];
        $email = $row['email'];
        $gender = $row['gender'];
        $role = $row['role'];
        
        echo '<tr>
        <th scope="row">' . $serialNumber++ . '</th>
                <td>' . $firstname . '</td>
                <td>' . $lastname . '</td>
                <td>' . $username . '</td>
                <td>' . $password . '</td>
                <td>' . $age . '</td>
                <td>' . $email . '</td>
                <td>' . $gender . '</td>
                <td>' . $role . '</td>
                
                <td>
                    <a href="update.php?
                    updateid='.$userid.'" class="update-btn">
                    <button>Update
                    </button>
                    </a>
                </td>
                <td>
                    <a href="delete.php?
                    deleteid='.$userid.'"class="delete-btn">
                    <button>Delete</button>
                    </a>
                </td>
            </tr>';
    }
}
   ?> 




    </table>

    </body>
</html>
