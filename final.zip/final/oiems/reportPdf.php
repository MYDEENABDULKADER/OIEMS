<?php
session_start();
if (!isset($_SESSION['loggedIn'])) {
  header('Location:home.php');
  exit();
}
?>

<?php
require_once("./inc/constants.php");
require_once('./inc/database.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);?>

<?php
$selectedEventId = isset($_POST['selectEventName']) ? $_POST['selectEventName'] : '';
$queryEvents = "SELECT eventid, eventname FROM eventtable";
$resultEvents = $mysqli->query($queryEvents);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }

        form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 70%;
            width: 100%;
            margin: 20px auto;
        }

        label {
            display: block;
            margin: 15px 0 5px;
            color: #555;
            font-weight: bold;
        }

        select,
        button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        #participantsDetails {
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tbody tr:hover {
            background-color: #f5f5f5;
        }

        .print-button {
            background-color: #3498db;
            color: white;
            border: none;
            width: fit-content;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 5%;
        }

        .print-button:hover {
            background-color: #3498db;
        }
    </style>
</head>

<body>

    <h1>Event Management</h1>
    <nav>
        <a href="admin.php">Admin</a>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Management</a>
        <a href="reportPdf.php">Reports</a>
        <a href="guestmanagement.php">Guest Management</a>
        <a href="./noticeboard/notice.php">Notice Board</a>
        <a href="feedbackmanagement.php">Feedback</a>
        <a href="logout.php">Logout</a>
    </nav>

    <center>
        <p>Select event name to get further details</p>
    </center>

    <form action="" method="post" id="reportForm" onsubmit="return validateForm()">
        <label for="selectEventName">Select Event Name:</label>
        <select name="selectEventName" id="selectEventName" onchange="this.form.submit()">
            <option value="">--Select Event--</option>
            <?php
            $queryEvents = "SELECT eventid, eventname FROM eventtable";
            $resultEvents = $mysqli->query($queryEvents);
            if ($resultEvents && $resultEvents->num_rows > 0) {
                while ($row = $resultEvents->fetch_assoc()) {

                    $eventId = $row['eventid'];
                    $eventName = $row['eventname'];
                    $selected = ($selectedEventId == $eventId) ? 'selected' : '';
                    echo "<option value='$eventId' $selected>$eventName</option>";
                }
            } else {
                echo "<option value=''>No events found</option>";
            }
            ?>
        </select>

        <label for='selectCompetitionName'>Select Competition Name:</label>
        <select name='selectCompetitionName' id='selectCompetitionName' onchange='this.form.submit()'>
            <option value=''>--Select Competition--</option>
            <?php
            include('db.php');
            if (isset($_POST['selectEventName']) && !empty($_POST['selectEventName'])) {
                $selectedEventId = $_POST['selectEventName'];
                $queryCompetitions = "SELECT comp_id, comp_name FROM comp_table WHERE eventid = ?";
                $stmt = $mysqli->prepare($queryCompetitions);
                $stmt = $mysqli->prepare($queryCompetitions);
                if (!$stmt) {
                    die('Prepare failed: ' . $mysqli->error);
                }
                $stmt->bind_param("s", $selectedEventId);
                if (!$stmt->execute()) {
                    die('Execute failed: ' . $stmt->error);
                }
                $resultCompetitions = $stmt->get_result();
                if ($resultCompetitions->num_rows > 0) {
                    while ($row = $resultCompetitions->fetch_assoc()) {
                        $competitionId = $row['comp_id'];
                        $competitionName = $row['comp_name'];
                        $selected = ($_POST['selectCompetitionName'] == $competitionName) ? 'selected' : '';
                        echo "<option value='$competitionName' $selected>$competitionName</option>";
                    }
                } else {
                    echo "<option value=''>No competitions found for this event</option>";
                }
                $stmt->close();
            }
            ?>
        </select>

        <div id="participantsDetails" style="text-align:right">
            <?php
            if (isset($_POST['selectCompetitionName']) && !empty($_POST['selectCompetitionName'])) {
                $selectedCompetitionName = $_POST['selectCompetitionName'];
                $queryParticipants = "
                    SELECT  
                        p.partname, 
                        p.yearofstudy, 
                        g.collegename, 
                        g.deptname, 
                        p.comp
                    FROM 
                        participants p
                    JOIN 
                        guest_table g ON p.guestid = g.guestid
                    WHERE 
                        TRIM(p.comp) LIKE CONCAT('%', ?, '%')
                ";
                $stmt = $mysqli->prepare($queryParticipants);
                if (!$stmt) {
                    die('Prepare failed: ' . $mysqli->error);
                }
                $stmt->bind_param("s", $selectedCompetitionName);
                if (!$stmt->execute()) {
                    die('Execute failed: ' . $stmt->error);
                }
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    echo "<table border='1'>";
                    echo "<tr><th>Participant Name</th><th>Year of Study</th><th>College Name</th><th>Department Name</th></tr>";
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['partname'] . "</td>";
                        echo "<td>" . $row['yearofstudy'] . "</td>";
                        echo "<td>" . $row['collegename'] . "</td>";
                        echo "<td>" . $row['deptname'] . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                    echo "<button class='print-button' onclick='printTable()'>Print Report</button>";
                } else {
                    echo "No participants found for this competition.";
                }
                $stmt->close();
            }
            ?>
        </div>

    </form>
    <script>
        function printTable() {
            var prtContent = document.getElementById("participantsDetails");
            var reportContent = document.createElement('div');
            var participantsTable = prtContent.querySelector('table').cloneNode(true);
            var totalParticipants = prtContent.querySelectorAll('table tr').length - 1;
            var reportTemplate = `
            <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 20px;
                    }
                    .report {
                        width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                        border: 1px solid #ccc;
                        background-color: #fff;
                    }
                    h1 {
                        text-align: center;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-top: 20px;
                    }
                    th, td {
                        padding: 8px;
                        border-bottom: 1px solid #ddd;
                        text-align: left;
                    }
                    th {
                        background-color: #f2f2f2;
                    }
                    .total {
                        margin-top: 20px;
                        text-align: right;
                        font-weight: bold;
                    }
                </style>
            </head>
            <body>
               
                <div class="report">
                <h1>Event Management System </h1>
                    <h1>Participant Report</h1>
                    <table>
                        ${participantsTable.innerHTML}
                    </table>
                    <div class="total">
                        <strong>Total Participants: </strong>${totalParticipants}
                    </div>
                </div>
            </body>
            </html>
        `;

            var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
            WinPrint.document.write(reportTemplate);
            WinPrint.document.close();


            setTimeout(function() {
                WinPrint.print();

            }, 100);
        }
    </script>





</body>

</html>