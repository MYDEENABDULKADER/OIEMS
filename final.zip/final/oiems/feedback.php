
<?php
include('db.php');
$message = ""; // Initialize an empty message variable

if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $fdate=$_POST['fdate'];
    $ename=$_POST['ename'];
    $collname=$_POST['collname'];
    $feedback=$_POST['feedback'];

    $sql="INSERT INTO `feedback`(name,email,f_date,ename,collname,feedback)
    values('$name','$email','$fdate','$ename','$collname','$feedback') ";

    $result = mysqli_query($conn, $sql);

    if($result){
        $message = "Thanks for your feedback!"; // Set the message
        echo "<script>alert('$message'); window.location.href = 'home.php';</script>"; // Display alert with message and redirect
        exit(); // terminate script execution after redirection
    } else {
        $message = "Error: " . mysqli_error($conn); // Set the error message
        echo "<script>alert('$message'); window.location.href = 'home.php';</script>"; // Display alert with error message and redirect
        exit(); // terminate script execution after redirection
    }
}
?>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .feedback-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .feedback-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="date"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .form-group textarea {
            resize: vertical;
        }

        button[type="submit"] {
            display: inline-block;
            width: 48%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        button[type="reset"] {
            display: inline-block;
            width: 48%;
            padding: 10px;
            background-color: red;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            transition: background-color 0.3s;
        }

        button[type="reset"]:hover {
            background-color: #b30000;
        }

        .button-group {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="feedback-container">
        <h2>Feedback Form</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="feedback-date">Feedback Date:</label>
                <input type="date" id="feedback-date" name="fdate" required>
            </div>
            <div class="form-group">
                <label for="event-name">Event Name:</label>
                <input type="text" id="event-name" name="ename" required>
            </div>
            <div class="form-group">
                <label for="college-name">College Name:</label>
                <input type="text" id="college-name" name="collname" required>
            </div>
            <div class="form-group">
                <label for="feedback">Feedback:</label>
                <textarea id="feedback" name="feedback" rows="4" required></textarea>
            </div>
            <div class="button-group">
                <button type="submit" name="submit">Submit Feedback</button>
                <button type="reset">Reset</button>
            </div>
        </form>
    </div>
</body>
</html>
