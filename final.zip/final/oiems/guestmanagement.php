<?php
session_start();

if (empty($_SESSION["mail_success"])) $_SESSION["mail_success"] = false;
if (empty($_SESSION["mail_error"])) $_SESSION["mail_error"] = false;

$success = $_SESSION["mail_success"];
$error = $_SESSION["mail_error"];

?>

<?php

if (!isset($_SESSION['loggedIn'])) {
    header('Location:home.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest Management Page</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: white;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        a {
            text-decoration: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        thead {
            color: black;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tbody tr:hover {
            background-color: #f5f5f5;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }

        .approve-btn button {
            background-color: #007bff;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .approve-btn button:hover {
            background-color: #0056b3;
        }


        #competitionModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        #competitionModalContent {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        #competitionModalContent table {
            width: 100%;
            border-collapse: collapse;
        }

        #competitionModalContent th,
        #competitionModalContent td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        #competitionModalContent tbody tr:hover {
            background-color: #f5f5f5;
        }

        p {
            font-size: larger;
            color: black;
            text-align: center;
            margin-top: 25px;
            cursor: pointer;
            text-decoration: none;

        }
    </style>
</head>

<body>


    <h1>Guest Management</h1>
    <nav>
        <a href="admin.php">Admin</a>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Organiser</a>
        <a href="guestmanagement.php">Guest Management</a>
        <a href="reportPdf.php">Reports</a>
        <a href="./noticeboard/notice.php">Notice Board</a>
        <a href="feedbackmanagement.php">Feedback</a>
        <a href="logout.php">Logout</a>
        <!-- <a href="#">Button</a> -->
    </nav>
    <p>Click the row to see the participants</p>
    <table border="2px">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>CollegeName</th>
                <th>Department Name</th>
                <th>Department Incharge</th>
                <th>Department Mail id</th>
                <th>Department Incharge number</th>
                <th>Event Name</th>
                <th>Food</th>
                <th>Approval Status</th>
                <th colspan="2" style="text-align: center;">Operation</th>
            </tr>
        </thead>
        <tbody id="userTableBody">
            <?php
            include('db.php');
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                function updateApprovalStatus($guestid, $status)
                {
                    // Implement your database update logic here
                    // ...
                }

                if (isset($_POST['action']) && isset($_POST['guestid']) && isset($_POST['deptmail'])) {
                    $action = $_POST['action'];
                    $guestid = $_POST['guestid'];
                    $deptmail = $_POST['deptmail'];

                    if ($action == 'approve') {
                        updateApprovalStatus($guestid, 'APPROVED');
                    } elseif ($action == 'reject') {
                        updateApprovalStatus($guestid, 'REJECTED');
                    }
                }
            }
            $sql = "SELECT * FROM `guest_table`";
            $result = mysqli_query($conn, $sql);


            if ($result) {
                $serialNumber = 1;

                while ($row = mysqli_fetch_assoc($result)) {
                    // Escape output to prevent XSS attacks
                    $guestid = htmlspecialchars($row['guestid']);
                    $collegename = htmlspecialchars($row['collegename']);
                    $deptname = htmlspecialchars($row['deptname']);
                    $deptincharge = htmlspecialchars($row['deptincharge']);
                    $deptmail = htmlspecialchars($row['deptmail']);
                    $inch_num = htmlspecialchars($row['inch_num']);
                    $eventname = htmlspecialchars($row['eventname']);
                    $meals = htmlspecialchars($row['meals']);

            ?>
                    <tr onclick="openModal('guest', '<?php echo $guestid; ?>')">
                <?php
                    // echo "<tr onclick='openModal(event, '" . $guestid . "')>
                    echo " <td>$serialNumber</td>
                            <td>$collegename</td>
                            <td>$deptname</td>
                            <td>$deptincharge</td>
                            <td>$deptmail</td>
                            <td>$inch_num</td>
                            <td>$eventname</td>
                            <td>$meals</td>
                            <td>{$row['approval_status']}</td>
                            <td style='text-align: center;'>
                                <div class='approve-btn'>
                                    <button onclick=\"approveGuest('$guestid', '$deptmail')\">Approve</button>
                                </div>
                            </td>
                        </tr>";
                    $serialNumber++;
                }
            }
                ?>
        </tbody>
    </table>
    <div id="competitionModal">
        <div id="competitionModalContent">
            <span onclick="closeModal()" style="cursor: pointer; position: absolute; top: 10px; right: 10px; font-size: 20px;">&times;</span>
            <table>
                <thead>
                    <tr>
                        <th>S.NO</th>
                        <th>Participant Name</th>
                        <th>Year of Study</th>
                        <th>Competitions</th>

                    </tr>
                </thead>
                <tbody id="partiTableBody">

                </tbody>
            </table>
        </div>
    </div>
    <script>
        function approveGuest(guestid, deptmail) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "update_approval_status.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    console.log(xhr.responseText);
                    location.reload(); // Reload the page after successful approval
                }
            };

            var data = "action=approve&guestid=" + encodeURIComponent(guestid) + "&deptmail=" + encodeURIComponent(deptmail);
            xhr.send(data);
        }

        function openModal(guest, guestId) {

            // Check if the clicked element is an anchor tag (a)
            if (event.target.tagName.toLowerCase() === 'a') {
                // Check if the clicked anchor tag has a specific class (you can adjust the class name accordingly)
                if (event.target.classList.contains('no-modal')) {
                    // Do not open the modal for certain links
                    return;
                }
            }
            event.preventDefault();

            // Display the modal
            document.getElementById('competitionModal').style.display = 'block';

            // Update the competition details in the modal
            updatepartiDetails(guestId);

        }

        function updatepartiDetails(guestId) {

            // Fetch competition details based on eventId and update the modal content
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {

                    // Update the competition table body with the fetched details
                    document.getElementById('partiTableBody').innerHTML = this.responseText;
                }
            };
            xhttp.open("GET", 'getpartidetails.php?guestid=' + guestId, true);
            xhttp.send();
        }

        function closeModal() {
            document.getElementById('competitionModal').style.display = 'none';
        }
    </script>
</body>

</html>