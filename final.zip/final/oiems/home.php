<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Event Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em 0;
        }

        section {
            padding: 2em;
            text-align: center;
        }

        .modal-button {
            background-color: #007BFF;
            padding: 10px 20px;
            color: white;
            position: fixed;
            font-size: 16px;
            border-radius: 5px;
            position: absolute;
            left: 93%;
            top: 9.5%;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em 0;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        .login-modal {
            display: none;
            position: fixed;
            left: 33%;
            max-width: 400px;
            width: 100%;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .modal-button:hover {
            background-color: #0056b3;
        }

        .close-modal {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            color: #555;
            cursor: pointer;
        }

        .close-modal:hover {
            color: #333;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 16px;
            margin-bottom: 8px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button[name="register"] {
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            position: absolute;
            left: 78%;
            top: 10%;
        }

        .notice-board {
            padding: 2em;
        }

        .card {
            max-width: 300px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .card:hover{
            cursor:pointer;
        }

        .card-header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .card-content {
            color: #555;
            margin-bottom: 15px;
        }
        /* Style for the feedback button */
/* Style for the feedback button */
button.feedback-button {
    background-color:aquamarine; /* Button background color */
    color:black; /* Button text color */
    padding: 10px 20px; /* Padding around the button text */
    font-size: 16px; /* Font size of the button text */
    border: none; /* Remove button border */
    border-radius: 5px; /* Rounded corners for the button */
    cursor: pointer; /* Cursor style on hover */
    transition: background-color 0.3s; /* Smooth transition for background color change */
    position: fixed; /* Position the button */
    left: 20px; /* Distance from the right edge */
    top: 65px; /* Distance from the top edge */
}


/* Hover effect for the feedback button */
button.feedback-button:hover {
    background-color: #0056b3; 
    color:whitesmoke;/* Ddarker background color on hover */
}

    </style>
</head>

<body>

    <header>
        <h1>Online Intercollegiate Event Management System</h1>
        <button class="feedback-button" onclick="window.location.href = 'feedback.php';">Feedback</button>

    </header>

    <section>
        <h2>Welcome to our Event Management System!</h2>
        <button class="modal-button" onclick="openModal()">Login</button>
        <div class="overlay" id="overlay" onclick="closeModal()"></div>

        <div class="login-modal" id="loginModal">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            <h2>Login</h2>
            <!-- Add your login form here -->
            <form action="login_check.php" method="post">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit" style="background-color: #007bff; color: #fff;padding: 10px 20px; border-radius: 50px; cursor: pointer;">Login</button>
            </form>
        </div>
        <a href="addguest.php">
            <button type="button" name="register">Click for Registration</button>
        </a>
    </section>

    <div class="notice-board">
        <!-- Sample notice cards -->

        <?php
        // Assume $notices is an array of notices fetched from the database
        include('db.php');

        $notices = array(); // Initialize an empty array

        $sql = "SELECT * FROM Notices";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all rows from the result set and store them in the $notices array
            while ($row = $result->fetch_assoc()) {
                $notices[] = $row;
            }
        }

        // Wrap all the cards with a single <marquee> tag
        echo '<marquee width="300px";"behavior="scroll" direction="up" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();">';
        foreach ($notices as $notice) {
          echo '<div class="card">';
          echo '<div class="card-header">' . htmlspecialchars($notice['title']) . '</div>';
          echo '<div class="card-body">';
          echo '<div class="card-title">' . htmlspecialchars($notice['title']) . '</div>';
          echo '<div class="card-content">' . htmlspecialchars($notice['content']) . '</div>';
          
          // Display link section only if the link is not null
          if (!empty($notice['link'])) {
            // Construct the full URL to the file
            $fileUrl = htmlspecialchars('./noticeboard/' . $notice['link']);
            echo '<div class="card-link"><a href="' . $fileUrl . '" download>Download Link</a></div>';
        }
        
        
          
          echo '</div>';
          echo '</div>';
      }
        echo '</marquee>';
        ?>
    </div>

    <footer>
    <p>&copy; 2023 Online InterCollegiate Event Management System. All rights reserved.</p>
    <!-- Feedback button -->
</footer>


</body>

<script>
    function openModal() {
        document.getElementById('loginModal').style.display = 'block';
        document.getElementById('overlay').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
    }
</script>

</html>
