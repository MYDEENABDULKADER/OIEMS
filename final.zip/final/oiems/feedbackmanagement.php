<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Management Page</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: white;
;        }

        h1 {
            color: #333;
            text-align: center;
        }

        a {
            text-decoration: none;
            }



table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

thead {
    color: black;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

tbody tr:hover {
    background-color: #f5f5f5;
}
nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }


/* Styles for the Reject button */
.delete-btn button {
    background-color: #dc3545; /* Red background color */
    color: #fff;              /* Text color */
    padding: 12px 20px;        /* Padding around text */
    border: none;             /* No border */
    border-radius: 5px;        /* Rounded corners */
    cursor: pointer;          /* Cursor on hover */
    font-size: 16px;          /* Font size */
}

.delete-btn button:hover {
    background-color: #c82333; /* Darker red on hover */
}
</style>

</head>
<body>

    <h1>Feedback Management</h1>
    <nav>
        <a href="admin.php">Admin</a>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Organiser</a>
        <a href="guestmanagement.php">Guest Management</a> 
        <a href="reportPdf.php">Reports</a>
        <a href="./noticeboard/notice.php">Notice Board</a>
        <a href="feedbackmanagement.php">Feedback</a>
        <a href="logout.php">Logout</a>
        <!-- <a href="#">Button</a> -->
    </nav>


    <body>
    
<table border="2px">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Feedback Date</th>
                <th>Event name</th>
                <th>College Name</th>
                <th>Feedback</th>
                <th >Operation</th>
            </tr>
        </thead>
        <tbody id="userTableBody" >
            
        </tbody>
        </body>
        </html>

<?php
        include('db.php');
$sql = "select * from `feedback` ";
$result = mysqli_query($conn,$sql);
if ($result) {
    $serialNumber = 1; // Initialize serial number

    while ($row = mysqli_fetch_assoc($result)) {
        $fid = $row['f_id'];
        $name = $row['name'];
        $email = $row['email'];
        $fdate = isset($row['f_date']) ? $row['f_date'] : ''; 
        $ename = $row['ename'];
        $collname = $row['collname'];
        $feedback = $row['feedback'];
        
        echo '<tr>
                <th scope="row">' . $serialNumber++ . '</th>
                <td>' . $name . '</td>
                <td>' . $email . '</td>
                <td>' . $fdate . '</td>
                <td>' . $ename . '</td>
                <td>' . $collname . '</td>
                <td>' . $feedback . '</td>
                <td>
                    <a href="delfed.php?deleteid='.$fid.'" class="delete-btn">
                    <button>Delete</button>
                    </a>
                </td>
            </tr>';
    }
}
?>


    </table>

    </body>
</html>
