<?php 
    include ('db.php');
    $eventId = mysqli_real_escape_string($conn, $_GET['eventid']);

    // Fetch competitions based on event ID
    $query = "SELECT comp_name,comp_id FROM comp_table WHERE eventid = '$eventId'";
    $result = mysqli_query($conn, $query);

    // Check if query was successful
    if ($result) {
        // Generate checkboxes for competitions
        $events = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            
            $events++;
            echo '<input type=hidden name=txtename' . $events . ' id=txtename' . $events . ' value=' . $row['comp_name'] . ' />'; 
            echo '<input type=hidden name=txteid' . $events . ' id=txteid'. $events . ' value=' . $row['comp_id'] . ' />'; 
        }

        // Output the checkboxes
        echo '<input type=hidden id=txtTotalEvents value=' . $events . ' />';
    } else {
        // Query was unsuccessful
        echo "Error: " . mysqli_error($conn);
    }
?>
