<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest Management Page</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: lightgreen;
      }

        h1 {
            color: #333;
            text-align: center;
        }

        a {
            text-decoration: none;
            }


table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

thead {
    color: black;
}

th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

tbody tr:hover {
    background-color: #f5f5f5;
}
nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }
        .approve-btn button {
    background-color: #007bff;
    color: #fff;             
    padding: 12px 20px;       
    border: none;             
    border-radius: 5px;        /* Rounded corners */
    cursor: pointer;          /* Cursor on hover */
    font-size: 16px;          /* Font size */
}

.approve-btn button:hover {
    background-color: #0056b3; /* Darker blue on hover */
}

/* Styles for the Reject button */
.reject-btn button {
    background-color: #dc3545; /* Red background color */
    color: #fff;              /* Text color */
    padding: 12px 20px;        /* Padding around text */
    border: none;             /* No border */
    border-radius: 5px;        /* Rounded corners */
    cursor: pointer;          /* Cursor on hover */
    font-size: 16px;          /* Font size */
}

.reject-btn button:hover {
    background-color: #c82333; /* Darker red on hover */
}
</style>

</head>
<body>

    <h1>Guest Management</h1>
    <nav>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Organiser</a>
        <a href="guestmanagement.php">Guest Management</a> 
        <a href="reportPdf.php">Reports</a>
        <a href="#">Notice Board</a>
        <a href="logout.php">Logout</a>
       
    </nav>


    <body>
    
<table border="2px">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>CollegeName</th>
                <th>Department Name</th>
                <th>Department Incharge</th>
                <th>Department Mail id</th>
                <th>Department Incharge number</th>
                <th>Event Name</th>
                <th>Food</th>
                <th>Approval Status</th>

                <th colspan="2" style="text-align: center;">Operation</th>
            </tr>
        </thead>
        <tbody id="userTableBody" >
            
        </tbody>
        </body>
        </html>

<?php
include('db.php');
include('mailconfig.php');
$sql = "SELECT * FROM `guest_table`";
$result = mysqli_query($conn,$sql);
if ($result) {
    $serialNumber = 1; 

    while ($row = mysqli_fetch_assoc($result)) {
        $guestid = $row['guestid'];
        $collegename = $row['collegename'];
        $deptname = $row['deptname'];
        $deptincharge = $row['deptincharge'];
        $deptmail = $row['deptmail'];
        $inch_num = $row['inch_num'];
        $eventname = $row['eventname'];
        $meals = $row['meals'];
        
        echo '<tr>
                    <th scope="row">' . $serialNumber++ . '</th>
                    <td>' . $collegename . '</td>
                    <td>' . $deptname . '</td>
                    <td>' . $deptincharge . '</td>
                    <td>' . $deptmail . '</td>
                    <td>' . $inch_num . '</td>
                    <td>' . $eventname . '</td>
                    <td>' . $meals . '</td>
                    <td>' . ($row['approval_status'] ? 'Approved' : 'Not Approved') . '</td>

                    <td>
                        <a class="approve-btn">
                            <button>
                                Approve
                            </button>
                        </a>
                    </td>

                    <td>
                         <a  class="reject-btn">
                            <button>
                                Reject
                            </button>
                        </a>
                    </td>



                </tr>';
                
                
    }
}

?> 
</table>
</body>
</html>
