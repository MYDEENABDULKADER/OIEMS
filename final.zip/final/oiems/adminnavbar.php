<nav>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Organiser</a>
        <a href="guestmanagement.php">Guest Management</a> 
        <a href="reportPdf.php">Reports</a>
        <a href="#">Notice Board</a>
        <a href="logout.php">Logout</a>
        <!-- <a href="#">Butto</a> -->
</nav>