<?php
session_start();
if (!isset($_SESSION['loggedIn'])) {
  header('Location:home.php');
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }

        .admin-content {
            padding: 20px;
            text-align:center;
        }
    </style>
</head>
<body>

    <nav>
        <a href="admin.php">Admin</a>
        <a href="staff_management.php">Staff Management</a>
        <a href="event_management.php">Event Organiser</a>
        <a href="guestmanagement.php">Guest Management</a> 
        <a href="reportPdf.php">Reports</a>
        <a href="./noticeboard/notice.php">Notice Board</a>
        <a href="feedbackmanagement.php">Feedback</a>
        <a href="logout.php">Logout</a>
        <!-- <a href="#">Button</a> -->
    </nav>

    <div class="admin-content">
        <!-- Your admin content goes here -->
        <h2>Welcome to the Admin Page</h2>
        <!-- <p>This is a basic admin page with a navigation bar.</p> -->
    </div>

</body>
</html>
