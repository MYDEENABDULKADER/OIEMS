<?php
include('db.php');
if(isset($_GET['deleteid'])){
    $eventid=$_GET['deleteid'];
    $sql="delete from `eventtable` where eventid='$eventid'";
    $result=mysqli_query($conn,$sql);
    if($result){
        header('location:event_management.php');
    }
    else{
        die(mysqli_error($conn));
    }
}
?>