<?php
include('db.php');
include('random_number.php');

$eventid = $_GET['updateid'];

$sql = "SELECT * FROM eventtable WHERE eventid = '$eventid'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

$eventname = $row['eventname'];
$startdate = $row['sdate'];
$enddate = $row['edate'];
$location = $row['location'];
$eventtype = $row['etype'];
$eventorg = $row['eorganiser'];
$estatus = $row['estatus'];
$eventid = $row['eventid'];

// Fetching existing competitions data
$compQuery = "SELECT * FROM comp_table WHERE eventid='$eventid'";
$compRes = mysqli_query($conn, $compQuery);

if ($compRes) {
    $compData = [];
    while ($comprow = mysqli_fetch_assoc($compRes)) {
        $compData[] = $comprow;
    }
    $numberofcompetitions = count($compData);
} else {
    die(mysqli_error($conn));
}

if (isset($_POST['submit'])) {
    $eventname = $_POST['ename'];
    $startdate = $_POST['sdate'];
    $enddate = $_POST['edate'];
    $location = $_POST['loc'];
    $eventtype = $_POST['etype'];
    $eventorg = $_POST['eorg'];
    $estatus = $_POST['estatus'];

    $sql = "UPDATE eventtable SET 
        eventname = '$eventname',
        sdate = '$startdate',
        location = '$location',
        etype = '$eventtype',
        eorganiser = '$eventorg',
        estatus = '$estatus'
        WHERE eventid = '$eventid'";
    $result = mysqli_query($conn, $sql);


if ($result) {
    // Update or insert competition data
    for ($i = 1; $i <= $numberofcompetitions + 1; $i++) {
        $competitionid = isset($_POST["competitionid$i"]) ? $_POST["competitionid$i"] : '';
        $competitionname = $_POST["competitionname$i"];
        $compstartdate = $_POST["sdate$i"];
        $complocation = $_POST["location$i"];
        $comptype = $_POST["comptype$i"];
        $compincharge = $_POST["competitionInCharge$i"];
        $compfee = $_POST["fee$i"];

        if (!empty($competitionname) && !empty($compstartdate)) {
            if (!empty($competitionid)) {
                // Update existing competition data
                $updateQuery = "UPDATE comp_table SET 
                    comp_name = '$competitionname',
                    sdate = '$compstartdate',
                    location = '$complocation',
                    comp_type = '$comptype',
                    comp_incharge = '$compincharge',
                    comp_fee = '$compfee'
                    WHERE comp_id = '$competitionid'";
                mysqli_query($conn, $updateQuery);
            } else {
                // Insert new competition data
                $insertQuery = "INSERT INTO comp_table (comp_name, sdate, location, comp_type, comp_incharge, comp_fee, eventid) 
                    VALUES ('$competitionname', '$compstartdate', '$complocation', '$comptype', '$compincharge', '$compfee', '$eventid')";
                mysqli_query($conn, $insertQuery);
            }
        }
    }

    // Redirect after processing
    header('location:event_management.php');
    exit; // Always exit after a header redirect
} else {
    die(mysqli_error($conn));
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Event and Competition</title>
    <link rel="stylesheet" href="stylenav.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        form {
            max-width: 90%;
            margin: 20px auto;
            background: #fff;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: #555;
        }

        input,
        select {
            width: 90%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Competition Table Styles */
        table {
            width: 90%;
            border-collapse: collapse;
            margin-top: 20px;
            color: #212529;
        }

        th,
        td {
            border: 1px solid #dee2e6;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tbody tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <h2>Update Event and Competitions</h2>
        <label for="ename">Event Name:</label>
        <input type="text" name="ename" value="<?php echo $eventname; ?>" required>

        <label for="sdate">Start Date:</label>
        <input type="date" name="sdate" value="<?php echo $startdate; ?>" required>

        <label for="edate">End Date:</label>
        <input type="date" name="edate" value="<?php echo $enddate; ?>" required>

        <label for="loc">Location:</label>
        <input type="text" name="loc" value="<?php echo $location; ?>" required>

        <label for="etype">Event Type:</label>
        <select name="etype" required>
            <option value="Intercollegiate" <?php if ($eventtype == 'Intercollegiate') echo 'selected'; ?>>Intercollegiate</option>
            <option value="Department" <?php if ($eventtype == 'Department') echo 'selected'; ?>>Department</option>
            <option value="Cultutal" <?php if ($eventtype == 'Cultural') echo 'selected'; ?>>Cultural</option>
            <option value="Sports" <?php if ($eventtype == 'Sports') echo 'selected'; ?>>Sports</option>
         </select>

        <label for="eorg">Event Organiser:</label>
        <input type="text" name="eorg" value="<?php echo $eventorg; ?>" required>

        <label for="estatus">Event Status:</label>
        <select name="estatus" required>
            <option value="Upcoming" <?php if ($estatus == 'Upcoming') echo 'selected'; ?>>Upcoming</option>
            <option value="Ongoing" <?php if ($estatus == 'Ongoing') echo 'selected'; ?>>Ongoing</option>
            <option value="Completed" <?php if ($estatus == 'Completed') echo 'selected'; ?>>Completed</option>

        </select>

        <table>
            <thead>
                <tr>
                    <th>Competition Name</th>
                    <th>Competition Date</th>
                    <th>Location</th>
                    <th>Competition Type</th>
                    <th>Competition In Charge</th>
                    <th>Fee</th>
                </tr>
            </thead>
            <tbody id="competitionTableBody">
                <?php
                for ($i = 1; $i <= $numberofcompetitions; $i++) {
                    $competitionname = $compData[$i - 1]['comp_name'];
                    $startdate = $compData[$i - 1]['sdate'];
                    $location = $compData[$i - 1]['location'];
                    $comptype = $compData[$i - 1]['comp_type'];
                    $compincharge = $compData[$i - 1]['comp_incharge'];
                    $fee = $compData[$i - 1]['comp_fee'];
                    $competitionid = $compData[$i - 1]['comp_id'];
                    ?>
                    <tr>
                        <td><input type="text" name="competitionname<?php echo $i; ?>" value="<?php echo $competitionname; ?>"></td>
                        <td><input type="date" name="sdate<?php echo $i; ?>" value="<?php echo $startdate; ?>"></td>
                        <td><input type="text" name="location<?php echo $i; ?>" value="<?php echo $location; ?>"></td>
                        <td><input type="text" name="comptype<?php echo $i; ?>" value="<?php echo $comptype; ?>"></td>
                        <td><input type="text" name="competitionInCharge<?php echo $i; ?>" value="<?php echo $compincharge; ?>"></td>
                        <td><input type="text" name="fee<?php echo $i; ?>" value="<?php echo $fee; ?>"></td>
                        <input type="hidden" name="competitionid<?php echo $i; ?>" value="<?php echo $competitionid; ?>">
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <div style="display: flex; justify-content: center; align-items: center; margin: 20px;">
            <button type="button" onclick="addCompetitionRow()">Add Competition</button>
        </div>
        <div style="display: flex; justify-content: center; align-items: center; margin: 20px;">
            <button type="submit" name="submit">Update</button>
        </div>
    </form>

    <script>
        function addCompetitionRow() {
        var tableBody = document.getElementById("competitionTableBody");
        var rowCount = tableBody.rows.length + 1;

        var row = tableBody.insertRow(-1);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
        var cell5 = row.insertCell(4);
        var cell6 = row.insertCell(5);

        cell1.innerHTML = '<input type="text" name="competitionname' + rowCount + '"required>';
        cell2.innerHTML = '<input type="date" name="sdate' + rowCount + '"required>';
        cell3.innerHTML = '<input type="text" name="location' + rowCount + '"required>';
        cell4.innerHTML = '<select name="comptype' + rowCount + '" required>' +
                      '<option value="Single">Single</option>' +
                      '<option value="Group">Group</option>' +
                      '</select>';
        cell5.innerHTML = '<input type="text" name="competitionInCharge' + rowCount + '"required>';
        cell6.innerHTML = '<input type="number" name="fee' + rowCount + '"required>';

        // Hidden input for competition ID
        var hiddenInput = document.createElement("input");
        hiddenInput.setAttribute("type", "hidden");
        hiddenInput.setAttribute("name", "competitionid" + rowCount);
        hiddenInput.setAttribute("value", '');
        row.appendChild(hiddenInput);
    }

</script>
</body>
</html>