
<?php
// Establish connection to your database
include('db.php'); // Include your database connection file

// Check if eventid parameter is set and is numeric
if(isset($_GET['eventid']) ) {
    // Sanitize the eventid parameter to prevent SQL injection
    $eventId = mysqli_real_escape_string($conn, $_GET['eventid']);

    // Fetch competitions based on event ID
    $query = "SELECT comp_name FROM comp_table WHERE eventid = '$eventId'";
    $result = mysqli_query($conn, $query);

    // Check if query was successful
    if ($result) {
        // Generate checkboxes for competitions
        $checkboxes = '';
        while ($row = mysqli_fetch_assoc($result)) {
            $checkboxes .= '<label><input type="checkbox" name="competitions[]" value="' . $row['comp_name'] . '"> ' . $row['comp_name'] . '</label>';
        }

        // Output the checkboxes
        echo $checkboxes;
    } else {
        // Query was unsuccessful
        echo "Error: " . mysqli_error($conn);
    }
} else {
    // Eventid parameter is missing or invalid
    echo "Invalid event ID.";
}

// Close database connection
mysqli_close($conn);
?>
