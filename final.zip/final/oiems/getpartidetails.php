<?php
// Include your database connection file
include('db.php');

// Check if eventid is set in the GET parameters
if (isset($_GET['guestid'])) {
    $selectedEventId = mysqli_real_escape_string($conn, $_GET['guestid']);

    // Query to fetch competition details based on eventid
    $sql = "SELECT * FROM `participants` WHERE guestid='$selectedEventId'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $serialNumber = 1;

        // Output competition details in HTML format
        while ($row = mysqli_fetch_assoc($result)) {
            $partname = $row['partname'];
            $yearofstudy = $row['yearofstudy'];
            $comp = $row['comp'];

            echo '<tr>
                    <th scope="row">' . $serialNumber++ . '</th>
                    <td>' . $partname . '</td>
                    <td>' . $yearofstudy . '</td>
                    <td>' . $comp . '</td>
                </tr>';
        }
    } else {
        // Handle database error
        echo '<tr><td colspan="8">Error fetching competition details</td></tr>';
    }
} else {
    // Handle missing eventid
    echo '<tr><td colspan="8">Event ID not provided</td></tr>';
}

// Close the database connection
mysqli_close($conn);
?>
