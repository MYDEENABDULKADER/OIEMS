<?php
include('db.php');
$userid=$_GET['updateid'];
$sql="select * from `user` where userid=$userid";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$userid = $row['userid'];
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$username = $row['username'];
$password = $row['password'];
$age = $row['age'];
$email = $row['email'];
$gender = $row['gender'];
$role = $row['role'];


if(isset($_POST['submit'])){

    $firstname=$_POST['fname'];
    $lastname=$_POST['lname'];
    $username=$_POST['uname'];
    $password=$_POST['pwd'];
    $age=$_POST['age'];
    $email=$_POST['email']; // added email field
    $gender=$_POST['gender'];
    $role=$_POST['role'];

    // $sql="update `user` set userid=$userid,firstname='$firstname',lastname='$lastname',username='$username',password='$password',age=$age,
    // email='$email',gender='$gender',college='$college',dept_name='$dept_name',staff_name='$staff_name',role='$role'";    
    $sql = "UPDATE `user` SET 
    firstname = '$firstname',
    lastname = '$lastname',
    username = '$username',
    password = '$password',
    age = $age,
    email = '$email',
    gender = '$gender',
    role = '$role'
    WHERE userid = $userid";

    $result=mysqli_query($conn,$sql);
   
    if($result){
        // echo "Data inserted successfully";
        header('location:staff_management.php');
    }
    else{
        die(mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add user</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
}

form {
    max-width: 400px;
    margin: 50px auto;
    background: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #333;
}

label {
    display: block;
    margin: 10px 0 5px;
    color: #555;
}

input,
select {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    background-color: #4caf50;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}


    </style>

</head>
<body>
    <form action="" method="post">
    <h2>Update User</h2>
    <label for="Firstname">FirstName:</label>
    <input type="text" name="fname" id="fname" placeholder="Enter Firstname" value=<?php echo $firstname;?> ><br>

    <label for="Lastname">LastName:</label>
    <input type="text" name="lname" id="lname" placeholder="Enter Lastname" value=<?php echo $lastname;?> ><br>

    <label for="Username">UserName:</label>
    <input type="text" name="uname" id="uname" placeholder="Enter Username" value=<?php echo $username;?>><br>

    <label for="Password">Password:</label>
    <input type="password"name="pwd" id="pwd" placeholder="Enter password" value=<?php echo $password;?>><br>

    <label for="Age">Age:</label>
    <input type="number" name="age"id="age" placeholder="Enter Age" value=<?php echo $age;?>><br>

    <label for="email">Email:</label>
    <input type="email"name="email" id="email" placeholder="Enter email" value=<?php echo $email;?>><br>
    
    <label for="Gender">Gender:</label>
    <select id="gender" name="gender">
            <option value="Male" <?php if($gender=='Male') echo 'selected'; ?>>Male</option>
            <option value="Female"<?php if($gender=='Female') echo 'selected'; ?>>Female</option>
    </select><br>

    <label for="role"  >Role:</label>
    <select name="role" id="role">
        <option value="HOD" <?php if($role=='HOD') echo 'selected'; ?> > HOD</option>
        <option value="Event Organiser"  <?php if($role=='Event Organiser')echo 'selected'; ?>>Event Organiser</option>
        <option value="Competition Incharge " <?php if($role=='Competition Incharge') echo 'selected'; ?>>Competition Incharge</option>
        <option value="Staff" <?php if($role=='Staff') echo 'selected'; ?>>Staff</option>
    </select>

    <button name="submit">Update</button>
    
</form>


</body>
</html>


