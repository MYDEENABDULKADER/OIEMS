<?php
// Include your database connection file
include('db.php');

// Check if eventid is set in the GET parameters
if (isset($_GET['eventid'])) {
    $selectedEventId = mysqli_real_escape_string($conn, $_GET['eventid']);

    // Query to fetch competition details based on eventid
    $sql = "SELECT * FROM `comp_table` WHERE eventid='$selectedEventId'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $serialNumber = 1;

        // Output competition details in HTML format
        while ($row = mysqli_fetch_assoc($result)) {
            $comp_id = $row['comp_id'];
            $comp_name = $row['comp_name'];
            $startdate = $row['sdate'];
            $location = $row['location'];
            $comp_type = $row['comp_type'];
            $comp_incharge = $row['comp_incharge'];
            $comp_fee = $row['comp_fee'];

            echo '<tr>
                    <th scope="row">' . $serialNumber++ . '</th>
                    <td>' . $comp_name . '</td>
                    <td>' . $startdate . '</td>
                    <td>' . $location . '</td>
                    <td>' . $comp_type . '</td>
                    <td>' . $comp_incharge . '</td>
                    <td>' . $comp_fee . '</td>
                    <td>
                        <a href="delcomp.php?deleteid=' . $comp_id . '" >Delete</a>
                    </td>

                </tr>';
        }
    } else {
        // Handle database error
        echo '<tr><td colspan="8">Error fetching competition details</td></tr>';
    }
} else {
    // Handle missing eventid
    echo '<tr><td colspan="8">Event ID not provided</td></tr>';
}

// Close the database connection
mysqli_close($conn);
?>
