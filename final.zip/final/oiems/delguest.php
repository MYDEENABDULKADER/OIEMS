<?php
include('db.php');
if(isset($_GET['deleteid'])){
    $guestid=$_GET['deleteid'];
    $sql="delete from `guest_table` where guestid='$guestid'";
    $result=mysqli_query($conn,$sql);
    if($result){
        header('location:guestmanagement.php');
    }
    else{
        die(mysqli_error($conn));
    }
}
?>