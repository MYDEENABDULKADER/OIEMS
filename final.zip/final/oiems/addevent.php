<?php
session_start();
if (!isset($_SESSION['loggedIn'])) {
  header('Location:home.php');
  exit();
}
?>


<?php
include('db.php');
require_once('random_number.php');
if (isset($_POST['submit'])) {
    $eventname = $_POST['ename'];
    $startdate = $_POST['sdate'];
    $enddate = $_POST['edate'];
    $location = $_POST['loc'];
    $eventtype = $_POST['etype'];
    $eventorg = $_POST['eorg'];
    $eventstatus = $_POST['estatus'];
    $eventid = generateUniquePrimaryKey();

    $sql = "INSERT INTO `eventtable` (eventid, eventname, sdate, edate, location, etype, eorganiser, estatus)
            VALUES ('$eventid', '$eventname', '$startdate', '$enddate', '$location', '$eventtype', '$eventorg', '$eventstatus')";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        $lastEventID = mysqli_insert_id($conn);

        // Assuming you have a form that takes the number of competitions
        $numberOfCompetitions = $_POST['numberOfCompetitions'];

        // Generate and process competition forms
        for ($i = 1; $i <= $numberOfCompetitions; $i++) {
            $competitionname = $_POST["competitionname$i"];
            $startdate = $_POST["sdate$i"];
            $location = $_POST["location$i"];
            $comptype = $_POST["comptype$i"];
            $compincharge = $_POST["competitionInCharge$i"];
            $fee = $_POST["fee$i"];

            // Insert into CompetitionTable with the retrieved EventID
            mysqli_query($conn, "INSERT INTO `comp_table` (comp_name, sdate, location, comp_type, comp_incharge, comp_fee, eventid) 
                VALUES ('$competitionname', '$startdate',  '$location', '$comptype', '$compincharge', $fee, '$eventid')");
        }

        header('location:event_management.php');
    } else {
        die(mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="stylenav.css">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Event and Competition</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        form {
            max-width: 90%;
            margin: 20px auto;
            background: #fff;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: #555;
        }

        input,
        select {
            width: 90%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Competition Table Styles */
        table {
            width: 90%;
            border-collapse: collapse;
            margin-top: 20px;
            color: #212529;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tbody+tbody {
            border-top: 2px solid #dee2e6;
        }
    </style>
</head>

<body>
    <h1 style="text-align: center;">Event Management</h1>

    <?php include('adminnavbar.php'); ?>

    <form action="" method="post">
        <h2>Add Event and Competitions</h2>
        <label for="EventName">EventName:</label>
        <input type="text" name="ename" id="ename" placeholder="Enter Eventname" required><br>

        <label for="StartDate">StartDate:</label>
        <input type="date" name="sdate" id="sdate" placeholder="Enter StartDate" required><br>

        <label for="EndDate">EndDate:</label>
        <input type="date" name="edate" id="edate" placeholder="Enter EndDate" required><br>

        <label for="Location">Location:</label>
        <input type="text" name="loc" id="loc" placeholder="Enter Location" required><br>

        <label for="EventType">EventType:</label>
        <select name="etype" id="etype" required>
            <option value="Intercollegiate">Intercollegiate</option>
            <option value="Department">Department</option>
            <option value="Cultural">Cultural</option>
            <option value="Sports">Sports</option>
        </select>

        <label for="EventOrganiser">EventOrganiser:</label>
        <input type="text" name="eorg" id="eorg" placeholder="Enter EventOrganiser" required><br>

        <label for="EventStatus">EventStatus:</label>
        <select id="estatus" name="estatus">
            <option value="Upcoming">Upcoming</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
        </select><br>

        <label for="numberOfCompetitions">Number of Competitions:</label>
        <input type="number" id="numberOfCompetitions" name="numberOfCompetitions" onblur="onBlurGenerateCompetitionInputs()" required>


        <table>
            <thead>
                <tr>
                    <th>Competition Name</th>
                    <th>Competition Date</th>
                    <th>Location</th>
                    <th>Competition Type</th>
                    <th>Competition In Charge</th>
                    <th>Fee</th>
                </tr>
            </thead>
            <tbody>
                <!-- Competition rows will be dynamically generated here based on user input -->
            </tbody>
        </table>

        <div style="display: flex; justify-content: center; align-items: center;margin: 20px;">
            <button type="submit" name="submit">Submit</button>
        </div>

    </form>

    <script>
        
        document.addEventListener('DOMContentLoaded', function () {
        // Set event status on page load
        updateEventStatus();

        // Add event listeners for start date and end date changes
        document.getElementById('sdate').addEventListener('input', updateEventStatus);
        document.getElementById('edate').addEventListener('input', updateEventStatus);
    });
        function updateEventStatus() {
            const startDate = new Date(document.getElementById('sdate').value);
            const endDate = new Date(document.getElementById('edate').value);
            const today = new Date();

            if (endDate < today) {
                document.getElementById('estatus').value = 'Completed';
            } else if (startDate <= today && endDate >= today) {
                document.getElementById('estatus').value = 'Ongoing';
            } else {
                document.getElementById('estatus').value = 'Upcoming';
            }
        }

        function onBlurGenerateCompetitionInputs() {
            const numberOfCompetitions = parseInt(document.getElementById('numberOfCompetitions').value, 10);
            const competitionTableBody = document.querySelector('table tbody');
            competitionTableBody.innerHTML = '';

            for (let i = 1; i <= numberOfCompetitions; i++) {
                const competitionRow = document.createElement('tr');

                competitionRow.innerHTML = `
                <td>
                    <input type="text" name="competitionname${i}" placeholder="Enter Competition Name" required>
                </td>
                <td>
                    <input type="date" name="sdate${i}" required>
                </td>
                <td>
                    <input type="text" name="location${i}" placeholder="Enter Location" required>
                </td>
                <td>
                    <select name="comptype${i}">
                        <option value="Single">Single</option>
                        <option value="Group">Group</option>
                    </select>
                </td>
                <td>
                    <input type="text" name="competitionInCharge${i}" placeholder="Enter InCharge Name" required>
                </td>
                <td>
                    <input type="number" name="fee${i}" placeholder="Enter Fee" required>
                </td>
            `;

                competitionTableBody.appendChild(competitionRow);
            }
        }
    </script>

</body>

</html>